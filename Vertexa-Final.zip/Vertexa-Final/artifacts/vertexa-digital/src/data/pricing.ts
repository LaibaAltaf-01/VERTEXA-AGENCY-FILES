// Indicative starting ranges shown on the site. EDIT THESE to your real prices.
// currency symbol is set in `currency`; `unit` is shown under the range.
export const currency = '$';

export const pricing: { service: string; min: number; max: number; unit: string }[] = [
  { service: 'Web Development', min: 150, max: 1500, unit: 'per project' },
  { service: 'Graphic Design & Branding', min: 40, max: 400, unit: 'per project' },
  { service: 'Search Engine Optimization', min: 80, max: 600, unit: 'per month' },
  { service: 'AI Automation & Artificial Intelligence', min: 150, max: 2000, unit: 'per project' },
  { service: 'Social Media Management', min: 100, max: 500, unit: 'per month' },
  { service: 'Digital Marketing', min: 150, max: 800, unit: 'per month' },
  { service: 'Meta Ads', min: 80, max: 500, unit: 'per month · ad spend extra' },
  { service: 'Video Editing', min: 20, max: 300, unit: 'per video' },
  { service: 'Content Writing', min: 10, max: 150, unit: 'per piece' },
  { service: 'Cybersecurity', min: 50, max: 800, unit: 'per project' },
  { service: 'Mobile App Development', min: 500, max: 5000, unit: 'per project' },
  { service: 'Thesis Writing', min: 100, max: 600, unit: 'per project' },
  { service: 'Virtual Assistant', min: 150, max: 600, unit: 'per month' },
];
