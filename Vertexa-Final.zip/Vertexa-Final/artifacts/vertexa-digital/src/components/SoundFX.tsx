import { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { sound } from '@/lib/sound';

const HOVER = 'a, button, summary, .chip-cloud li, .price-card, .service-row';

/** Global UI sounds via event delegation + a floating mute toggle. */
export default function SoundFX() {
  const [on, setOn] = useState(sound.enabled);
  const last = useRef<Element | null>(null);
  const lastAt = useRef(0);

  useEffect(() => {
    const canHover = window.matchMedia('(hover: hover)').matches;
    const over = (e: PointerEvent) => {
      if (!canHover || e.pointerType !== 'mouse') return;
      const el = (e.target as Element | null)?.closest(HOVER);
      if (!el || el === last.current) { if (!el) last.current = null; return; }
      last.current = el;
      const now = performance.now();
      if (now - lastAt.current > 90) { lastAt.current = now; sound.hover(); }
    };
    const down = (e: PointerEvent) => {
      if ((e.target as Element | null)?.closest('[data-sound-toggle]')) return;
      if ((e.target as Element | null)?.closest(HOVER)) sound.click();
    };
    document.addEventListener('pointerover', over, { passive: true });
    document.addEventListener('pointerdown', down, { passive: true });
    return () => { document.removeEventListener('pointerover', over); document.removeEventListener('pointerdown', down); };
  }, []);

  return (
    <button
      type="button" className="sound-toggle" data-sound-toggle data-testid="button-sound-toggle"
      aria-pressed={on} aria-label={on ? 'Mute site sounds' : 'Turn on site sounds'}
      onClick={() => { const n = !on; setOn(n); sound.set(n); }}
    >
      {on ? <Volume2 size={16} /> : <VolumeX size={16} />}<span>{on ? 'Sound on' : 'Sound off'}</span>
    </button>
  );
}
