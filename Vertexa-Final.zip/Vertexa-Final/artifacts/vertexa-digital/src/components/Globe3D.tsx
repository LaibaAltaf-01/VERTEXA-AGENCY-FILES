import { useEffect, useRef } from 'react';

/** Rotating 3D node-globe (perspective projection, depth-shaded links). Tilts toward the cursor. */
export default function Globe3D({ className = '', nodes = 95 }: { className?: string; nodes?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const pts = Array.from({ length: nodes }, (_, i) => { // fibonacci sphere
      const y = 1 - (i / (nodes - 1)) * 2, r = Math.sqrt(1 - y * y), t = i * 2.399963;
      return { x: Math.cos(t) * r, y, z: Math.sin(t) * r, hot: i % 7 === 0 };
    });
    let w = 0, h = 0, dpr = 1, raf = 0, visible = true, ay = 0;
    let tx = 0, ty = 0, cx = 0, cy = 0;

    function resize() {
      const rect = canvas!.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = rect.width; h = rect.height;
      canvas!.width = Math.max(1, Math.floor(w * dpr));
      canvas!.height = Math.max(1, Math.floor(h * dpr));
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    function frame() {
      raf = requestAnimationFrame(frame);
      if (!visible) return;
      if (!reduce) ay += 0.0042;
      cx += (tx - cx) * 0.05; cy += (ty - cy) * 0.05;
      ctx!.clearRect(0, 0, w, h);
      const R = Math.min(w, h) * 0.38, f = 3.2;
      const rotY = ay + cx, rotX = 0.35 + cy;
      const sy = Math.sin(rotY), cyy = Math.cos(rotY), sx = Math.sin(rotX), cxx = Math.cos(rotX);
      const pr = pts.map((p) => {
        const x1 = p.x * cyy + p.z * sy, z1 = -p.x * sy + p.z * cyy;
        const y2 = p.y * cxx - z1 * sx, z2 = p.y * sx + z1 * cxx;
        const s = f / (f - z2);
        return { sx: w / 2 + x1 * R * s, sy: h / 2 + y2 * R * s, z: z2, s, hot: p.hot, ox: x1, oy: y2 };
      });
      // soft core glow
      const g = ctx!.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, R * 1.2);
      g.addColorStop(0, 'rgba(190,30,30,.16)'); g.addColorStop(1, 'rgba(190,30,30,0)');
      ctx!.fillStyle = g; ctx!.fillRect(0, 0, w, h);
      for (let i = 0; i < pr.length; i++) {
        for (let j = i + 1; j < pr.length; j++) {
          const d = Math.hypot(pts[i].x - pts[j].x, pts[i].y - pts[j].y, pts[i].z - pts[j].z);
          if (d < 0.5) {
            const depth = (pr[i].z + pr[j].z) / 2 * 0.5 + 0.5;
            ctx!.strokeStyle = `rgba(222,170,70,${(0.08 + depth * 0.45) * (1 - d / 0.5)})`;
            ctx!.lineWidth = 0.8;
            ctx!.beginPath(); ctx!.moveTo(pr[i].sx, pr[i].sy); ctx!.lineTo(pr[j].sx, pr[j].sy); ctx!.stroke();
          }
        }
      }
      for (const p of [...pr].sort((a, b) => a.z - b.z)) {
        const depth = p.z * 0.5 + 0.5;
        ctx!.fillStyle = p.hot ? `rgba(240,90,60,${0.4 + depth * 0.6})` : `rgba(235,195,100,${0.3 + depth * 0.7})`;
        ctx!.beginPath(); ctx!.arc(p.sx, p.sy, (p.hot ? 2.6 : 1.7) * p.s, 0, Math.PI * 2); ctx!.fill();
      }
    }

    const onMove = (e: PointerEvent) => {
      const r = canvas.getBoundingClientRect();
      tx = ((e.clientX - (r.left + r.width / 2)) / window.innerWidth) * 1.6;
      ty = ((e.clientY - (r.top + r.height / 2)) / window.innerHeight) * 0.9;
    };
    resize();
    const ro = new ResizeObserver(resize); ro.observe(canvas);
    const io = new IntersectionObserver(([e]) => { visible = e.isIntersecting; }); io.observe(canvas);
    window.addEventListener('pointermove', onMove, { passive: true });
    raf = requestAnimationFrame(frame);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); io.disconnect(); window.removeEventListener('pointermove', onMove); };
  }, [nodes]);

  return <canvas ref={ref} className={className} aria-hidden="true" />;
}
