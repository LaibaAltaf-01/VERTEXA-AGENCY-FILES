import { useEffect, useRef, useState } from 'react';
import { ArrowRight, ArrowUpRight, ChevronLeft, Compass, X } from 'lucide-react';
import './agency-guide.css';

type GuideRoute = {
  id: string;
  label: string;
  title: string;
  answer: string;
  nextStep: string;
};

const routes: GuideRoute[] = [
  {
    id: 'website',
    label: 'Build or improve a website',
    title: 'A clearer place to do business.',
    answer: 'Vertexa works on business and corporate websites, e-commerce, landing pages, portfolio sites, and considered redesigns.',
    nextStep: 'We can start with what your website needs to help people understand or do.',
  },
  {
    id: 'identity',
    label: 'Shape a brand or visual identity',
    title: 'Give the brand a point of view.',
    answer: 'Brand identity and graphic design can include logo work, visual guidelines, social creatives, company profiles, packaging, and marketing materials.',
    nextStep: 'Tell us where the current identity feels unclear, or what you are creating from scratch.',
  },
  {
    id: 'visibility',
    label: 'Reach the right people',
    title: 'Make the next move purposeful.',
    answer: 'The right starting point may be search visibility, social media management, or paid digital campaigns. The best fit depends on your audience and goals.',
    nextStep: 'Share who you want to reach and what you would like them to do.',
  },
  {
    id: 'search',
    label: 'Improve search visibility',
    title: 'Build useful search foundations.',
    answer: 'SEO support can include keyword research, on-page and technical checks, content optimization, and local SEO foundations.',
    nextStep: 'A little context about your website and audience helps define a realistic scope.',
  },
  {
    id: 'workflow',
    label: 'Explore an AI or workflow solution',
    title: 'Start with the work, not the tool.',
    answer: 'Vertexa discusses AI integrations and workflow assistance where they fit a real business need, including suitable automation and customer-support solutions.',
    nextStep: 'Describe the repetitive task or customer need you want to make easier. Suitability and scope are discussed before work begins.',
  },
  {
    id: 'uncertain',
    label: 'I’m still figuring it out',
    title: 'That is a useful place to start.',
    answer: 'You do not need to arrive with a finished brief. Vertexa can first understand your business, audience, priorities, and the challenge you want to solve.',
    nextStep: 'A short note about what you are building is enough to begin the conversation.',
  },
];

export default function AgencyGuide() {
  const [open, setOpen] = useState(false);
  const [route, setRoute] = useState<GuideRoute | null>(null);
  const firstOptionRef = useRef<HTMLButtonElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (open) firstOptionRef.current?.focus();
  }, [open, route]);

  function closeGuide(restoreFocus = true) {
    setOpen(false);
    if (restoreFocus) window.setTimeout(() => triggerRef.current?.focus(), 0);
  }

  return (
    <div className="vertexa-guide" data-testid="widget-agency-guide">
      {open && (
        <section
          id="vertexa-guide-panel"
          className="vertexa-guide__panel"
          role="region"
          aria-labelledby="vertexa-guide-title"
          aria-describedby="vertexa-guide-note"
          data-testid="panel-agency-guide"
        >
          <div className="vertexa-guide__topline">
            <span className="vertexa-guide__brand"><Compass size={14} aria-hidden="true" /> VERTEXA / FIELD GUIDE</span>
            <button
              type="button"
              className="vertexa-guide__icon-button"
              onClick={() => closeGuide()}
              aria-label="Close agency guide"
              data-testid="button-guide-close"
            >
              <X size={17} aria-hidden="true" />
            </button>
          </div>

          <div className="vertexa-guide__content" aria-live="polite">
            {route ? (
              <div className="vertexa-guide__answer" data-testid={`answer-guide-${route.id}`}>
                <p className="vertexa-guide__eyebrow">A useful direction</p>
                <h2 id="vertexa-guide-title">{route.title}</h2>
                <p className="vertexa-guide__copy">{route.answer}</p>
                <p className="vertexa-guide__next">{route.nextStep}</p>
                <div className="vertexa-guide__actions">
                  <a
                    className="vertexa-guide__contact"
                    href="#contact"
                    onClick={() => closeGuide(false)}
                    data-testid="link-guide-contact"
                  >
                    Start a conversation <ArrowUpRight size={15} aria-hidden="true" />
                  </a>
                  <button
                    type="button"
                    className="vertexa-guide__back"
                    onClick={() => setRoute(null)}
                    data-testid="button-guide-back"
                  >
                    <ChevronLeft size={14} aria-hidden="true" /> Choose another
                  </button>
                </div>
              </div>
            ) : (
              <>
                <p className="vertexa-guide__eyebrow">A considered first step</p>
                <h2 id="vertexa-guide-title">What are you looking to move forward?</h2>
                <p className="vertexa-guide__copy">Choose a direction. This guide uses predefined service information to point you to a useful next step.</p>
                <div className="vertexa-guide__options" aria-label="Choose a project direction">
                  {routes.map((item, index) => (
                    <button
                      key={item.id}
                      ref={index === 0 ? firstOptionRef : undefined}
                      type="button"
                      className="vertexa-guide__option"
                      onClick={() => setRoute(item)}
                      data-testid={`button-guide-topic-${item.id}`}
                    >
                      <span>{item.label}</span><ArrowRight size={15} aria-hidden="true" />
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
          <p className="vertexa-guide__note" id="vertexa-guide-note" data-testid="text-guide-disclosure">
            A fixed service guide, not an automated or AI conversation.
          </p>
        </section>
      )}

      <button
        ref={triggerRef}
        type="button"
        className={`vertexa-guide__trigger${open ? ' is-open' : ''}`}
        aria-expanded={open}
        aria-controls={open ? 'vertexa-guide-panel' : undefined}
        onClick={() => setOpen((value) => !value)}
        data-testid="button-guide-toggle"
      >
        <span className="vertexa-guide__trigger-mark" aria-hidden="true">{open ? <X size={17} /> : <Compass size={17} />}</span>
        <span>{open ? 'Close guide' : 'Find your direction'}</span>
      </button>
    </div>
  );
}
