import { useEffect, useRef } from 'react';

/**
 * Drifting particle web. Nearby nodes link to each other, and nodes near the
 * cursor reach out and join it (and each other) so the web "catches" the pointer.
 */
export default function NetworkCanvas({ className = '', density = 11000 }: { className?: string; density?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    type P = { x: number; y: number; vx: number; vy: number; r: number; hot: boolean };
    let w = 0, h = 0, dpr = 1, raf = 0, visible = true;
    let pts: P[] = [];
    const mouse = { x: -9999, y: -9999, on: false };
    const LINK = 125, MOUSE = 190;

    function resize() {
      const rect = canvas!.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = rect.width; h = rect.height;
      canvas!.width = Math.max(1, Math.floor(w * dpr));
      canvas!.height = Math.max(1, Math.floor(h * dpr));
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.min(130, Math.max(24, Math.floor((w * h) / density)));
      pts = Array.from({ length: count }, () => ({
        x: Math.random() * w, y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.35, vy: (Math.random() - 0.5) * 0.35,
        r: Math.random() * 1.4 + 0.7, hot: Math.random() < 0.22,
      }));
    }

    function frame() {
      raf = requestAnimationFrame(frame);
      if (!visible) return;
      ctx!.clearRect(0, 0, w, h);
      for (const p of pts) {
        if (!reduce) {
          p.x += p.vx; p.y += p.vy;
          if (p.x < 0 || p.x > w) p.vx *= -1;
          if (p.y < 0 || p.y > h) p.vy *= -1;
          if (mouse.on) { // gentle pull toward the cursor
            const dx = mouse.x - p.x, dy = mouse.y - p.y, d = Math.hypot(dx, dy);
            if (d < MOUSE && d > 40) { p.x += (dx / d) * 0.35; p.y += (dy / d) * 0.35; }
          }
        }
      }
      for (let i = 0; i < pts.length; i++) {
        const a = pts[i];
        for (let j = i + 1; j < pts.length; j++) {
          const b = pts[j], d = Math.hypot(a.x - b.x, a.y - b.y);
          if (d < LINK) {
            const near = mouse.on && Math.hypot(a.x - mouse.x, a.y - mouse.y) < MOUSE && Math.hypot(b.x - mouse.x, b.y - mouse.y) < MOUSE;
            ctx!.strokeStyle = near ? `rgba(240,130,60,${(1 - d / LINK) * 0.75})` : `rgba(212,175,55,${(1 - d / LINK) * 0.26})`;
            ctx!.lineWidth = near ? 1 : 0.6;
            ctx!.beginPath(); ctx!.moveTo(a.x, a.y); ctx!.lineTo(b.x, b.y); ctx!.stroke();
          }
        }
        if (mouse.on) {
          const d = Math.hypot(a.x - mouse.x, a.y - mouse.y);
          if (d < MOUSE) {
            ctx!.strokeStyle = `rgba(255,150,80,${(1 - d / MOUSE) * 0.9})`;
            ctx!.lineWidth = 1;
            ctx!.beginPath(); ctx!.moveTo(a.x, a.y); ctx!.lineTo(mouse.x, mouse.y); ctx!.stroke();
          }
        }
        ctx!.fillStyle = a.hot ? 'rgba(235,90,60,.95)' : 'rgba(228,190,95,.9)';
        ctx!.beginPath(); ctx!.arc(a.x, a.y, a.r, 0, Math.PI * 2); ctx!.fill();
      }
    }

    const onMove = (e: PointerEvent) => {
      const r = canvas.getBoundingClientRect();
      mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top;
      mouse.on = mouse.x >= 0 && mouse.y >= 0 && mouse.x <= r.width && mouse.y <= r.height;
    };
    const onLeave = () => { mouse.on = false; };

    resize();
    const ro = new ResizeObserver(resize); ro.observe(canvas);
    const io = new IntersectionObserver(([e]) => { visible = e.isIntersecting; }); io.observe(canvas);
    window.addEventListener('pointermove', onMove, { passive: true });
    document.addEventListener('pointerleave', onLeave);
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf); ro.disconnect(); io.disconnect();
      window.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerleave', onLeave);
    };
  }, [density]);

  return <canvas ref={ref} className={className} aria-hidden="true" />;
}
