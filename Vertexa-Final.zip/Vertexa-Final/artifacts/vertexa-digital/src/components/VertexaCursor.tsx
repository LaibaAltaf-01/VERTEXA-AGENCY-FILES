import { useEffect, useRef } from 'react';
import './vertexa-cursor.css';

export default function VertexaCursor() {
  const cursorRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<number | null>(null);
  const pointRef = useRef({ x: -100, y: -100 });

  useEffect(() => {
    const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    let enabled = false;

    const updatePosition = () => {
      frameRef.current = null;
      const node = cursorRef.current;
      if (!node) return;
      node.style.transform = `translate3d(${pointRef.current.x}px, ${pointRef.current.y}px, 0)`;
      node.style.opacity = '1';
    };

    const onMove = (event: PointerEvent) => {
      pointRef.current = { x: event.clientX, y: event.clientY };
      if (frameRef.current === null) frameRef.current = window.requestAnimationFrame(updatePosition);
    };
    const onLeave = () => {
      if (cursorRef.current) cursorRef.current.style.opacity = '0';
      document.documentElement.classList.remove('vertexa-cursor-active');
    };
    const onEnter = () => document.documentElement.classList.add('vertexa-cursor-active');
    const onPointerOver = (event: PointerEvent) => {
      const target = event.target;
      const interactive = target instanceof Element && target.closest('a, button, [role="button"], input, textarea, select, summary, label');
      cursorRef.current?.classList.toggle('is-interactive', Boolean(interactive));
    };

    const activate = () => {
      const shouldEnable = finePointer.matches && !reducedMotion.matches;
      if (shouldEnable === enabled) return;
      enabled = shouldEnable;
      if (enabled) {
        document.documentElement.classList.add('vertexa-cursor-active');
        window.addEventListener('pointermove', onMove, { passive: true });
        window.addEventListener('pointerover', onPointerOver, { passive: true });
        window.addEventListener('pointerleave', onLeave);
        window.addEventListener('pointerenter', onEnter);
      } else {
        document.documentElement.classList.remove('vertexa-cursor-active');
        window.removeEventListener('pointermove', onMove);
        window.removeEventListener('pointerover', onPointerOver);
        window.removeEventListener('pointerleave', onLeave);
        window.removeEventListener('pointerenter', onEnter);
        if (cursorRef.current) cursorRef.current.style.opacity = '0';
      }
    };

    activate();
    finePointer.addEventListener('change', activate);
    reducedMotion.addEventListener('change', activate);
    return () => {
      finePointer.removeEventListener('change', activate);
      reducedMotion.removeEventListener('change', activate);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerover', onPointerOver);
      window.removeEventListener('pointerleave', onLeave);
      window.removeEventListener('pointerenter', onEnter);
      document.documentElement.classList.remove('vertexa-cursor-active');
      if (frameRef.current !== null) window.cancelAnimationFrame(frameRef.current);
    };
  }, []);

  return (
    <div className="vertexa-cursor" aria-hidden="true" data-testid="decoration-custom-cursor" ref={cursorRef}>
      <span className="vertexa-cursor__ring" />
      <span className="vertexa-cursor__core" />
      <span className="vertexa-cursor__label">GO</span>
    </div>
  );
}
