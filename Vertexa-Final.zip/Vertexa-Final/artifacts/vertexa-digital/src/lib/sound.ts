// Tiny synthesized UI sounds (Web Audio) – no audio files needed.
let ctx: AudioContext | null = null;
let enabled = true;
try { enabled = localStorage.getItem('vx-sound') !== 'off'; } catch { /* ignore */ }

function ac() {
  if (!ctx) {
    const C = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!C) return null;
    ctx = new C();
  }
  if (ctx.state === 'suspended') void ctx.resume();
  return ctx;
}

function tone(freq: number, dur: number, vol: number, type: OscillatorType = 'sine', slideTo?: number, delay = 0) {
  const a = ac(); if (!a || !enabled) return;
  const t = a.currentTime + delay;
  const o = a.createOscillator(), g = a.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, t);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(a.destination); o.start(t); o.stop(t + dur + 0.02);
}

export const sound = {
  get enabled() { return enabled; },
  set(on: boolean) {
    enabled = on;
    try { localStorage.setItem('vx-sound', on ? 'on' : 'off'); } catch { /* ignore */ }
    if (on) { ac(); sound.open(); }
  },
  hover() { tone(1250, 0.07, 0.025, 'sine', 1700); },
  click() { tone(520, 0.09, 0.07, 'triangle', 260); tone(1040, 0.06, 0.03, 'sine', 780, 0.01); },
  open() { tone(330, 0.22, 0.05, 'sine', 660); tone(495, 0.26, 0.04, 'sine', 990, 0.07); },
  close() { tone(660, 0.18, 0.045, 'sine', 330); },
};
