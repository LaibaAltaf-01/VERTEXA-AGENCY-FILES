import { useEffect, useState, type FormEvent, type PointerEvent } from 'react';
import { ArrowRight, ArrowUpRight, BrainCircuit, Code2, FileText, GraduationCap, Headset, Linkedin, Mail, Megaphone, Menu, PenTool, Phone, Search, Share2, ShieldCheck, Smartphone, Target, Video, X } from 'lucide-react';
import logo from '@assets/WhatsApp_Image_2026-10-23_at_7.35.48_AM_1792770706061.jpeg';
import AgencyGuide from '@/components/agency-guide';
import AgencyCursor from '@/components/agency-cursor';
import NetworkCanvas from '@/components/NetworkCanvas';
import Globe3D from '@/components/Globe3D';
import SoundFX from '@/components/SoundFX';
import { sound } from '@/lib/sound';
import { currency, pricing } from '@/data/pricing';

const navItems = [
  ['About', '#about'],
  ['Services', '#services'],
  ['Pricing', '#pricing'],
  ['Process', '#process'],
  ['Why Vertexa', '#why'],
  ['FAQs', '#faqs'],
  ['Contact', '#contact'],
];

const serviceIcons = [Code2, PenTool, Search, BrainCircuit, Share2, Megaphone, Target, Video, FileText, ShieldCheck, Smartphone, GraduationCap, Headset];

const services = [
  {
    title: 'Web Development',
    description: 'Thoughtful, responsive websites built to make your business feel clear, credible, and ready for what comes next.',
    details: ['Business and corporate websites', 'E-commerce websites', 'Landing pages and portfolio websites', 'Responsive website design', 'Website redesign and maintenance'],
  },
  {
    title: 'Graphic Design & Branding',
    description: 'Distinctive visual identities and design systems that give your brand a consistent point of view.',
    details: ['Logo design and brand identity', 'Social media posts and ad creatives', 'Business cards and company profiles', 'Packaging and marketing materials', 'Brand guidelines and visual identity'],
  },
  {
    title: 'Search Engine Optimization',
    description: 'Practical SEO foundations that help the right people discover your business over time.',
    details: ['On-page and technical SEO', 'Keyword research', 'Website SEO audits', 'Content optimization', 'Local SEO and search visibility improvement'],
  },
  {
    title: 'AI Automation & Artificial Intelligence',
    description: 'Useful, considered AI integrations and workflows shaped around real business needs.',
    details: ['AI-assisted content and creative workflows', 'AI automation solutions', 'AI-powered business workflow assistance', 'AI chatbot and customer-support solutions, where suitable', 'Custom AI tools and integrations'],
  },
  {
    title: 'Social Media Management',
    description: 'Consistent social presence, content direction, and day-to-day care for your channels.',
    details: ['Social media account management', 'Content planning and calendars', 'Post and creative design', 'Captions and content writing', 'Audience engagement and page optimization'],
  },
  {
    title: 'Digital Marketing',
    description: 'Focused digital campaigns and growth support aligned with your goals and agreed scope.',
    details: ['Digital marketing strategy', 'Social media advertising', 'Google Ads campaign management', 'Lead generation campaigns', 'Marketing creatives and campaign optimization'],
  },
  {
    title: 'Meta Ads',
    description: 'Facebook and Instagram advertising set up and managed around your audience, offer, and budget.',
    details: ['Meta (Facebook & Instagram) ad campaigns', 'Audience research and targeting', 'Ad creative and copy', 'Lead generation and sales campaigns', 'Performance tracking and optimization'],
  },
  {
    title: 'Video Editing',
    description: 'Clean, well-paced edits that make your brand’s video content feel polished and ready to share.',
    details: ['Social media reels and short-form video', 'Promotional and ad videos', 'YouTube and long-form editing', 'Motion graphics, captions and subtitles', 'Colour correction and sound clean-up'],
  },
  {
    title: 'Content Writing',
    description: 'Clear, purposeful writing that gives your brand a voice and your audience a reason to stay.',
    details: ['Website copy and landing pages', 'Blog posts and SEO articles', 'Social media captions and scripts', 'Product descriptions', 'Brand voice and company profiles'],
  },
  {
    title: 'Cybersecurity',
    description: 'Practical security basics that help protect your website, accounts, and business data.',
    details: ['Website security checks and hardening', 'Account and password security guidance', 'Malware clean-up and recovery support', 'Backup and recovery planning', 'Security awareness for small teams'],
  },
  {
    title: 'Mobile App Development',
    description: 'Mobile apps designed and built to feel simple, fast, and genuinely useful for your customers.',
    details: ['Android and iOS app development', 'Cross-platform apps', 'App UI/UX design', 'Business and e-commerce apps', 'App updates and maintenance'],
  },
  {
    title: 'Thesis Writing',
    description: 'Academic writing support with clear structure, careful research, and proper formatting.',
    details: ['Thesis and dissertation support', 'Research proposals and literature reviews', 'Structuring and editing', 'Formatting and referencing', 'Proofreading and plagiarism checks'],
  },
  {
    title: 'Virtual Assistant',
    description: 'Dependable remote support that frees up your time for the work that moves your business.',
    details: ['Email and calendar management', 'Data entry and research', 'Customer inquiry handling', 'Document preparation and admin support', 'Social media and task coordination'],
  },
];

const steps = [
  ['01', 'Listen', 'We start with your business, audience, priorities, and the challenge you want to solve.'],
  ['02', 'Shape', 'Together, we define a clear direction, deliverables, timeline, and agreed scope.'],
  ['03', 'Build', 'We bring the work to life with care, regular communication, and thoughtful iteration.'],
  ['04', 'Move forward', 'We hand over clearly and help you understand the next practical steps.'],
];

const values = [
  ['01', 'Creativity with Purpose', 'Creative ideas shaped around the needs and goals of each project.'],
  ['02', 'Quality Over Quantity', 'Prioritizing thoughtful, well-crafted work.'],
  ['03', 'Honesty and Transparency', 'Clear expectations and honest conversations.'],
  ['04', 'Client-Focused Solutions', 'Solutions tailored to each client’s needs.'],
  ['05', 'Innovation and Continuous Learning', 'Staying curious and adapting as tools evolve.'],
  ['06', 'Attention to Detail', 'Careful attention across every detail.'],
  ['07', 'Reliable Communication', 'Keeping clients informed throughout the work.'],
  ['08', 'Long-Term Partnerships', 'Building relationships that can grow over time.'],
];

const questions = [
  ['Who do you work with?', 'We work with local Pakistani and international startups, small businesses, entrepreneurs, and growing brands.'],
  ['Can I work with you remotely?', 'Yes. Vertexa Digital serves clients remotely. We coordinate online and do not maintain a public office address.'],
  ['What happens after I get in touch?', 'We will learn about your goals, discuss the right service and clarify the scope before any work begins.'],
  ['How do you price a project?', 'The pricing section shows indicative ranges per service. Your final quote depends on the agreed deliverables and project requirements, and we confirm scope and expectations before starting.'],
  ['Do you offer every service as a package?', 'Services can be discussed individually or together. Any deliverables, timeline, and scope are agreed before work begins.'],
  ['Can you guarantee specific results?', 'No specific business or search outcomes are promised. We focus on thoughtful work, clear communication, and the agreed scope.'],
];

function mailtoForInquiry(name: string, email: string, service: string, budget: string, message: string) {
  const subject = `Project inquiry from ${name}`;
  const body = `Name: ${name}\nEmail: ${email}\nService of interest: ${service}\nBudget range: ${budget}\n\nProject details:\n${message}`;
  return `mailto:vertexadigitalofficial@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

const budgetRanges = [`Under ${currency}100`, `${currency}100 – ${currency}300`, `${currency}300 – ${currency}1,000`, `${currency}1,000 – ${currency}3,000`, `${currency}3,000+`, 'Not sure yet'];

function InquiryFields({ idPrefix }: { idPrefix: string }) {
  return (
    <>
      <div className="field"><label htmlFor={`${idPrefix}-name`}>Your name</label><input id={`${idPrefix}-name`} name="name" autoComplete="name" required placeholder="Name" data-testid={`input-${idPrefix}-name`} /></div>
      <div className="field"><label htmlFor={`${idPrefix}-email`}>Email address</label><input id={`${idPrefix}-email`} name="email" type="email" autoComplete="email" required placeholder="you@example.com" data-testid={`input-${idPrefix}-email`} /></div>
      <div className="field"><label htmlFor={`${idPrefix}-service`}>What are you looking for?</label><select id={`${idPrefix}-service`} name="service" defaultValue="" data-testid={`select-${idPrefix}-service`}><option value="" disabled>Select a service</option>{services.map(({ title }) => <option key={title}>{title}</option>)}<option>Not sure yet</option></select></div>
      <div className="field"><label htmlFor={`${idPrefix}-budget`}>Budget range</label><select id={`${idPrefix}-budget`} name="budget" defaultValue="" data-testid={`select-${idPrefix}-budget`}><option value="" disabled>Select a range</option>{budgetRanges.map((r) => <option key={r}>{r}</option>)}</select></div>
      <div className="field full"><label htmlFor={`${idPrefix}-message`}>A little about your project</label><textarea id={`${idPrefix}-message`} name="message" required placeholder="What are you working on, and what would you like to make possible?" data-testid={`input-${idPrefix}-message`} /></div>
      <p className="form-footnote">Submitting opens a prefilled email in your mail app. Project deliverables and scope are agreed together before work begins.</p>
      <button className="button-gold" type="submit" data-testid={`button-${idPrefix}-submit`}>Prepare Email <ArrowUpRight size={15} /></button>
    </>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [heroTilt, setHeroTilt] = useState({ x: 0, y: 0 });
  const [contactOpen, setContactOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = contactOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [contactOpen]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { setContactOpen(false); setMenuOpen(false); sound.close(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  function openContact() { setMenuOpen(false); setContactOpen(true); sound.open(); }

  function handleHeroPointerMove(event: PointerEvent<HTMLDivElement>) {
    if (event.pointerType !== 'mouse') return;
    const bounds = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width - 0.5;
    const y = (event.clientY - bounds.top) / bounds.height - 0.5;
    setHeroTilt({ x: y * -12, y: x * 14 });
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const name = String(form.get('name') ?? '').trim();
    const email = String(form.get('email') ?? '').trim();
    const service = String(form.get('service') ?? 'Not selected');
    const budget = String(form.get('budget') ?? 'Not selected');
    const message = String(form.get('message') ?? '').trim();
    window.location.href = mailtoForInquiry(name, email, service, budget, message);
  }

  return (
    <div className="site-shell">
      <header className="topbar">
        <div className="container nav-wrap">
          <a className="brand" href="#home" aria-label="Vertexa Digital home" data-testid="link-brand-home">
            <img src={logo} alt="Vertexa Digital official monogram" data-testid="img-brand-logo" />
            <span className="brand-label">VERTEXA<small>DIGITAL</small></span>
          </a>
          <nav className={`nav-links ${menuOpen ? 'open' : ''}`} aria-label="Main navigation">
            {navItems.map(([label, href]) => (
              <a key={href} href={href} onClick={() => setMenuOpen(false)} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`}>{label}</a>
            ))}
          </nav>
          <button className="nav-cta" type="button" onClick={openContact} data-testid="link-nav-start-project">Let’s Talk <ArrowUpRight size={12} /></button>
          <button className="menu-button" type="button" aria-label={menuOpen ? 'Close menu' : 'Open menu'} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)} data-testid="button-mobile-menu">
            {menuOpen ? <X size={21} /> : <Menu size={21} />}
          </button>
        </div>
      </header>

      <main>
        <section className="hero" id="home" aria-labelledby="hero-title">
          <div className="hero-bg-grid" aria-hidden="true" />
          <NetworkCanvas className="hero-network" />
          <div className="container">
            <div className="hero-content">
              <div className="hero-kicker reveal"><i className="gold-line" /><span className="eyebrow">Independent digital agency · Pakistan &amp; beyond</span></div>
              <h1 id="hero-title" className="reveal reveal-delay">Digital solutions,<br /><em>built to scale.</em></h1>
              <p className="hero-copy reveal reveal-delay">We unite thoughtful design, modern technology, and practical growth work to help ambitious businesses show up with confidence.</p>
              <div className="hero-actions reveal reveal-delay">
                <button type="button" onClick={openContact} className="button-gold" data-testid="link-hero-start-project">Start Your Project <ArrowUpRight size={15} /></button>
                <a href="#services" className="text-link" data-testid="link-hero-explore-services">Explore Our Services <span><ArrowRight size={15} /></span></a>
              </div>
            </div>
            <div className="hero-emblem-wrap" aria-label="Vertexa Digital, Ideas. Design. Code. Growth.">
              <Globe3D className="hero-globe" />
              <div className="hero-emblem-orbit hero-emblem-orbit-one" aria-hidden="true" />
              <div className="hero-emblem-orbit hero-emblem-orbit-two" aria-hidden="true" />
              <div
                className="hero-emblem"
                onPointerMove={handleHeroPointerMove}
                onPointerLeave={() => setHeroTilt({ x: 0, y: 0 })}
                style={{ transform: `perspective(1000px) rotateX(${heroTilt.x}deg) rotateY(${heroTilt.y}deg)` }}
              >
                <img src={logo} alt="Vertexa Digital official gold logo" />
              </div>
            </div>
            <div className="hero-bottom">
              <span>01 / Digital, with direction</span>
              <span className="scroll-cue"><i />Scroll to explore</span>
              <span>Ideas. Design. Code. Growth.</span>
            </div>
          </div>
        </section>

        <div className="service-ribbon" aria-label="Our services">
          <div className="ribbon-track">
            {[0, 1].map((group) => (
              <div className="ribbon-group" key={group} aria-hidden={group === 1}>
                {services.map(({ title }, i) => {
                  const Icon = serviceIcons[i];
                  return <span className="ribbon-item" key={`${group}-${title}`}><Icon aria-hidden="true" /><span>{title}</span><i className="ribbon-dot" /></span>;
                })}
              </div>
            ))}
          </div>
        </div>

        <section className="section section-light" id="about" aria-labelledby="about-heading">
          <div className="container intro-grid">
            <div>
              <span className="eyebrow">A considered start</span>
              <div className="intro-mark" aria-hidden="true">V.</div>
            </div>
            <div className="intro-copy">
              <h2 className="section-heading" id="about-heading">Built for the<br />next chapter.</h2>
              <p className="lead">We believe ambitious businesses deserve a digital presence that matches where they’re going.</p>
              <p>Vertexa Digital is an independent agency bringing design, technology, and growth work into one thoughtful partnership. We help startups, small businesses, entrepreneurs, and growing brands present themselves professionally—and move forward with confidence.</p>
              <p>We help businesses establish a professional brand identity, build effective websites, improve online visibility, manage social media, reach relevant audiences, and streamline suitable workflows with AI. Every solution is customized to the client’s goals and budget.</p>
              <p>Our mission is to empower businesses through exceptional design, modern web technologies, intelligent AI solutions, and effective digital marketing strategies.</p>
              <p>Founded in 2026, Vertexa Digital serves local and international startups, small businesses, entrepreneurs, and growing brands.</p>
              <div className="founder">
                <span className="founder-monogram">CU</span>
                <span><strong>Chaudhary Umar</strong><small>Founder</small></span>
              </div>
            </div>
          </div>
        </section>

        <section className="section section-dark" id="services" aria-labelledby="services-heading">
          <div className="container">
            <div className="services-head">
              <div><span className="eyebrow">What we do</span><h2 className="section-heading" id="services-heading">One partner.<br /><span className="gold">More possibility.</span></h2></div>
              <p>From a first impression to the systems behind it, our services are designed to work together around your real priorities.</p>
            </div>
            <p className="scope-note">Services are offered according to project requirements, available expertise, and agreed scope.</p>
            <div className="service-list">
              {services.map(({ title, description, details }, index) => {
                const Icon = serviceIcons[index];
                return (
                <article className="service-row" key={title} data-testid={`card-service-${index + 1}`}>
                  <span className="service-num">{String(index + 1).padStart(2, '0')}</span>
                  <h3><Icon className="service-icon" aria-hidden="true" />{title}</h3><p>{description}</p>
                  <a className="service-arrow" href="#contact" aria-label={`Ask about ${title}`} data-testid={`link-service-inquiry-${index + 1}`}><ArrowUpRight size={20} /></a>
                  <details className="service-details">
                    <summary data-testid={`button-service-details-${index + 1}`}>Explore what’s included</summary>
                    <ul>{details.map((detail) => <li key={detail}>{detail}</li>)}</ul>
                  </details>
                </article>
              );})}
            </div>
            <div style={{ marginTop: 32 }}><a href="#contact" className="text-link" data-testid="link-services-talk">Let’s Talk <span><ArrowRight size={15} /></span></a></div>
          </div>
        </section>

        <section className="section section-light pricing" id="pricing" aria-labelledby="pricing-heading">
          <div className="container">
            <div className="services-head">
              <div><span className="eyebrow">Pricing</span><h2 className="section-heading" id="pricing-heading">Clear ranges.<br />Honest quotes.</h2></div>
              <p>Indicative starting ranges for every service. Your exact quote depends on scope, and we agree it with you before any work begins.</p>
            </div>
            <div className="price-grid">
              {pricing.map(({ service, min, max, unit }, i) => (
                <article className="price-card" key={service} data-testid={`card-price-${i + 1}`}>
                  <h3>{service}</h3>
                  <div className="price-range"><span>{currency}{min.toLocaleString()}</span><i /><span>{currency}{max.toLocaleString()}</span></div>
                  <small>{unit}</small>
                  <button type="button" className="price-cta" onClick={openContact} data-testid={`button-price-quote-${i + 1}`}>Get a quote <ArrowUpRight size={13} /></button>
                </article>
              ))}
            </div>
            <p className="price-note">Ranges are indicative starting points, not fixed offers. Larger or custom projects are quoted individually.</p>
          </div>
        </section>

        <section className="section section-sand" id="process" aria-labelledby="process-heading">
          <div className="container">
            <span className="eyebrow">How we work</span>
            <h2 className="section-heading" id="process-heading">A clear path,<br />made together.</h2>
            <p className="muted" style={{ maxWidth: 500, fontSize: 13, lineHeight: 1.9 }}>No mystery steps. Just a considered process that gives good ideas the structure they need to become useful work.</p>
            <div className="process-grid">
              {steps.map(([number, title, copy]) => (
                <article className="process-step" key={number} data-testid={`card-process-step-${number}`}>
                  <span>{number}</span><h3>{title}</h3><p>{copy}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section connected" id="connected" aria-labelledby="connected-heading">
          <NetworkCanvas className="connected-network" density={14000} />
          <div className="container connected-grid">
            <div className="connected-copy">
              <span className="eyebrow">Everything, connected</span>
              <h2 className="section-heading" id="connected-heading">Every discipline.<br /><span className="gold">One connected team.</span></h2>
              <p>Strategy, design, code, content and growth rarely work alone. Here is everything Vertexa can bring to your project.</p>
              <ul className="chip-cloud" aria-label="All services">
                {services.map(({ title }) => <li key={title}>{title}</li>)}
              </ul>
              <button className="button-gold" type="button" onClick={openContact}>Start a conversation <ArrowRight size={15} /></button>
            </div>
            <div className="connected-globe"><Globe3D className="connected-globe-canvas" nodes={130} /></div>
          </div>
        </section>

        <section className="manifesto" aria-label="Start a project">
          <div className="container manifesto-inner">
            <div>
              <span className="eyebrow">For the ones building</span>
              <h2 className="section-heading">Your next move deserves<br />a digital partner.</h2>
            </div>
            <button className="button-gold button-dark" type="button" onClick={openContact} data-testid="button-manifesto-contact">Tell us what you’re building <ArrowRight size={15} /></button>
          </div>
        </section>

        <section className="section" id="why" aria-labelledby="why-heading">
          <div className="container why-layout">
            <div className="why-aside">
              <span className="eyebrow">Why Vertexa</span>
              <h2 className="section-heading" id="why-heading">Good work.<br />Good reasons.</h2>
              <p>We’re building an agency for people who care about how their business shows up—and want a partner who cares about the details, too.</p>
              <div className="benefits" aria-label="Ways we work">
                <span className="benefit">Direct collaboration</span><span className="benefit">Remote-ready</span><span className="benefit">Scope agreed up front</span><span className="benefit">One connected team</span>
              </div>
            </div>
            <div className="values-list">
              {values.map(([number, title, copy]) => (
                <article className="value-item" key={number} data-testid={`card-value-${number}`}>
                  <b>{number}</b><div><h3>{title}</h3><p>{copy}</p></div>
                </article>
              ))}
              <p className="remote-note">Serving clients remotely in Pakistan and internationally. No public office address.</p>
            </div>
          </div>
        </section>

        <section className="section faq-section" id="faqs" aria-labelledby="faq-heading">
          <div className="container faq-layout">
            <div><span className="eyebrow">A few useful answers</span><h2 className="section-heading" id="faq-heading">Good to<br />know.</h2><p className="muted" style={{ fontSize: 12, lineHeight: 1.8 }}>Have another question? <a className="gold" href="#contact" data-testid="link-faq-contact">Let’s talk directly.</a></p></div>
            <div className="faq-list">
              {questions.map(([question, answer], index) => {
                const expanded = openFaq === index;
                return <div className="faq-item" key={question}>
                  <button className="faq-question" type="button" aria-expanded={expanded} aria-controls={`faq-answer-${index}`} onClick={() => setOpenFaq(expanded ? null : index)} data-testid={`button-faq-${index + 1}`}>
                    <span>{question}</span><span aria-hidden="true">{expanded ? '−' : '+'}</span>
                  </button>
                  {expanded && <div className="faq-answer" id={`faq-answer-${index}`} data-testid={`text-faq-answer-${index + 1}`}>{answer}</div>}
                </div>;
              })}
            </div>
          </div>
        </section>

        <section className="section contact-section" id="contact" aria-labelledby="contact-heading">
          <div className="container contact-grid">
            <div className="contact-copy">
              <span className="eyebrow">Your next step starts here</span>
              <h2 className="section-heading" id="contact-heading">Let’s make<br /><span className="gold">something matter.</span></h2>
              <p>Tell us a little about what you’re building. We’ll get back to you to understand the opportunity and discuss a considered next step.</p>
              <div className="contact-lines">
                <a className="contact-line" href="mailto:vertexadigitalofficial@gmail.com" data-testid="link-contact-email"><span><Mail size={15} /></span>vertexadigitalofficial@gmail.com</a>
                <a className="contact-line" href="tel:+923215492627" data-testid="link-contact-phone"><span><Phone size={15} /></span>+92 321 5492627</a>
                <a className="contact-line" href="https://wa.me/923215492627" target="_blank" rel="noopener noreferrer" data-testid="link-contact-whatsapp"><span><ArrowUpRight size={15} /></span>Message us on WhatsApp</a>
                <a className="contact-line" href="https://www.instagram.com/vertexadigitalofficial/" target="_blank" rel="noopener noreferrer" data-testid="link-contact-instagram"><span aria-hidden="true">◎</span>Instagram</a>
                <a className="contact-line" href="https://www.linkedin.com/company/vertexa-digital" target="_blank" rel="noopener noreferrer" data-testid="link-contact-linkedin"><span><Linkedin size={15} /></span>LinkedIn</a>
                <a className="contact-line" href="https://www.facebook.com/share/1Bx7tuNWjs/" target="_blank" rel="noopener noreferrer" data-testid="link-contact-facebook"><span aria-hidden="true">f</span>Facebook</a>
              </div>
              <div className="remote-note">Remote service · Pakistan and international clients</div>
            </div>
            <form className="contact-form" onSubmit={handleSubmit} data-testid="form-project-inquiry">
              <InquiryFields idPrefix="contact" />
            </form>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="container">
          <div className="footer-top">
            <a className="brand" href="#home" data-testid="link-footer-home">
              <img src={logo} alt="" />
              <span className="brand-label">VERTEXA<small>DIGITAL</small></span>
            </a>
            <nav className="footer-nav" aria-label="Footer navigation">{navItems.map(([label, href]) => <a href={href} key={href} data-testid={`link-footer-${label.toLowerCase().replaceAll(' ', '-')}`}>{label}</a>)}</nav>
          </div>
          <div className="footer-bottom">
            <span>© 2026 Vertexa Digital · Ideas. Design. Code. Growth.</span>
            <div className="footer-social">
              <a href="https://www.instagram.com/vertexadigitalofficial/" target="_blank" rel="noopener noreferrer" data-testid="link-social-instagram">Instagram <ArrowUpRight size={11} /></a>
              <a href="https://www.linkedin.com/company/vertexa-digital" target="_blank" rel="noopener noreferrer" data-testid="link-social-linkedin"><Linkedin size={11} /> LinkedIn <ArrowUpRight size={11} /></a>
              <a href="https://www.facebook.com/share/1Bx7tuNWjs/" target="_blank" rel="noopener noreferrer" data-testid="link-social-facebook">Facebook <ArrowUpRight size={11} /></a>
              <a href="mailto:vertexadigitalofficial@gmail.com" data-testid="link-footer-email">Email <ArrowUpRight size={11} /></a>
            </div>
          </div>
        </div>
      </footer>
      <SoundFX />
      <AgencyGuide />
      <AgencyCursor />
      {contactOpen && (
        <div className="dialog-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setContactOpen(false); }}>
          <section className="dialog" role="dialog" aria-modal="true" aria-labelledby="dialog-title" data-testid="dialog-contact">
            <button className="dialog-close" type="button" aria-label="Close contact form" onClick={() => setContactOpen(false)}><X size={19} /></button>
            <span className="eyebrow dialog-eyebrow">A good place to begin</span>
            <h2 id="dialog-title">What are you building?</h2>
            <p>Tell us a little about your project. Your email app will open with your note ready to send to Vertexa Digital.</p>
            <form className="contact-form" onSubmit={handleSubmit}>
              <InquiryFields idPrefix="dialog" />
            </form>
          </section>
        </div>
      )}
    </div>
  );
}
