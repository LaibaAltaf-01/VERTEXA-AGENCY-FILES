# Vertexa Digital – final site
Site code: artifacts/vertexa-digital  (pnpm install, then: pnpm --filter @workspace/vertexa-digital run dev)
- Edit prices:   artifacts/vertexa-digital/src/data/pricing.ts
- Edit services: artifacts/vertexa-digital/src/pages/home.tsx (services array)
- Sounds:        src/lib/sound.ts (synthesized, no audio files); toggle bottom-left
- Effects:       src/components/NetworkCanvas.tsx (web) and Globe3D.tsx (3D globe)
